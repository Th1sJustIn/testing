# alpfa-team-4
Team_4 


Here we are developing Resume filter , where it filters resumes to find out potential candidates needed.

Here we are using 
Streamlit , ML models


here we implemented show relavent job that matches candidate profile, filter profiles and show potential candidates for Sponsors and career events members.

